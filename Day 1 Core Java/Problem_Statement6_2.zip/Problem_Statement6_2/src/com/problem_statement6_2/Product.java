package com.problem_statement6_2;

import java.util.Hashtable;
import java.util.Scanner;

public class Product {




public static void main(String[] args) {
	Scanner sc1 = new Scanner(System.in);
	Hashtable<String,String> pro=new Hashtable<String,String>();
	System.out.println("enter the product id and name;");
	for(int i=0;i<3;i++)
	{
		pro.put(sc1.next(),sc1.next());
	}
	System.out.println("the product list is:");
	System.out.println(pro);
	System.out.println("enter the product id to be removed:");
	String id = sc1.next();
	pro.remove(id);
	System.out.println("item removed");
	System.out.println("the product list is:");
	System.out.println(pro.toString());
	System.out.println("enter the product id to be searched:");
	String sid=sc1.next();
	if(pro.containsKey(sid))
	{
		System.out.println(pro.get(sid));
	}
	else {
		System.out.println("do not exist");
	}
}
}

