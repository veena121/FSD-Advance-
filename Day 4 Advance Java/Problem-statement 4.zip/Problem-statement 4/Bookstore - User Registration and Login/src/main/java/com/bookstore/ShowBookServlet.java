package com.bookstore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/showBook")
public class ShowBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("user");
		
		if(user!=null)
		{
			int id = Integer.parseInt(request.getParameter("id"));
			
			Connection conn = DBConfig.getConnection();
			if(conn!=null)
			{
				try
				{
					PreparedStatement stmt = conn.prepareStatement("select * from books where book_id=?");
					stmt.setInt(1, id);
					
					ResultSet rs = stmt.executeQuery();
					if(rs.next())
					{
						Book book = new Book(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
						session.setAttribute("selectedBook", book);
						response.sendRedirect("ShowDetails.jsp");
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
		else
		{
			response.sendRedirect("error");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
