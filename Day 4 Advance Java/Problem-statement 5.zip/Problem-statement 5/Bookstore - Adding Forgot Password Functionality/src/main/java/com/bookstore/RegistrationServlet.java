package com.bookstore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname = request.getParameter("fname");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String registrationDate = "2022-04-08";
		
		Connection conn = DBConfig.getConnection();
		
		if(conn!=null)
		{
			try
			{
				PreparedStatement stmt = conn.prepareStatement("insert into users (first_name, user_name, email, password, address, registration_date) values (?, ?, ?, ?, ?, ?)");
				stmt.setString(1, fname);
				stmt.setString(2, username);
				stmt.setString(3, email);
				stmt.setString(4, password);
				stmt.setString(5, address);
				stmt.setString(6, registrationDate);
				
				int rs = stmt.executeUpdate();
				if(rs > 0)
				{
					response.sendRedirect("Login.jsp");
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
