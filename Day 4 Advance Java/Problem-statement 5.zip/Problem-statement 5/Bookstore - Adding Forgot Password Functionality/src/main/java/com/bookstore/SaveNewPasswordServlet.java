package com.bookstore;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/saveNewPassword")
public class SaveNewPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String password = request.getParameter("password");
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("forgotedUsername");
		Connection conn = DBConfig.getConnection();
		response.setContentType("text/html");
		
		if(conn!=null)
		{
			try
			{
				PreparedStatement stmt = conn.prepareStatement("update users set password=? where user_name=?");
				stmt.setString(1, password);
				stmt.setString(2, username);
				
				int rs = stmt.executeUpdate();
				if(rs > 0)
				{
					response.sendRedirect("Login.jsp");
				}
				else
				{
					PrintWriter pw = response.getWriter();
					pw.print("There is some error in database plz try again");
					pw.print("<a href='Login.jsp'>Try Again</a>");
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
