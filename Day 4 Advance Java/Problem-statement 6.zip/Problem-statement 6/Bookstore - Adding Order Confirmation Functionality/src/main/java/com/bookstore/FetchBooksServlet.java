package com.bookstore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/getData")
public class FetchBooksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("user");
		
		if(user!=null)
		{
			Connection conn = DBConfig.getConnection();
			List<Book> books = new ArrayList<Book>();
			if(conn!=null)
			{
				try
				{
					String query = "select * from books";
					Statement stat = conn.createStatement();
					
					ResultSet rs = stat.executeQuery(query);
					while(rs.next())
					{
						Book book = new Book(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
						books.add(book);
					}
					session.setAttribute("books", books);
					response.sendRedirect("Welcome.jsp");
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				System.out.println("Error Connecting to Database");
			}
		}
		else
		{
			response.sendRedirect("error");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
