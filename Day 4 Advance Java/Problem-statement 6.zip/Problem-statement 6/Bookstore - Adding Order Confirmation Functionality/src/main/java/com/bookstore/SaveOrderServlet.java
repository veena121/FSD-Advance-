package com.bookstore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/saveOrder")
public class SaveOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("user");
		if(user!=null)
		{
			String custName = request.getParameter("custname");
			String phoneNo = request.getParameter("phoneNo");
			String address = request.getParameter("address");
			
			Book selectedBook = (Book) session.getAttribute("selectedBook");
			int bookId = selectedBook.getBookId();
			int quantity = (int) session.getAttribute("quantity");
			String orderDate = "2022-04-08";
			
			Connection conn = DBConfig.getConnection();
			if(conn!=null)
			{
				try
				{
					PreparedStatement stmt = conn.prepareStatement("insert into order_details (book_id, cust_name, phone_no, address, order_date, quantity) values (?, ?, ?, ?, ?, ?)");
					stmt.setInt(1, bookId);
					stmt.setString(2, custName);
					stmt.setString(3, phoneNo);
					stmt.setString(4, address);
					stmt.setString(5, orderDate);
					stmt.setInt(6, quantity);
					
					int rs = stmt.executeUpdate();
					if(rs > 0)
					{
						response.sendRedirect("OrderSuccess.jsp");
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
		else
		{
			response.sendRedirect("Error.jsp");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
