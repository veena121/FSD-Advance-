package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAO {

	public static boolean addProduct(Product product)
	{
		
		Connection conn = DBUtil.getConnection();
		
		if(conn!=null)
		{
			try 
			{
				PreparedStatement stat = conn.prepareStatement("insert into product (name, price) values(?, ?)");
				stat.setString(1, product.getName());
				stat.setInt(2, product.getPrice());
				
				int rs = stat.executeUpdate();
				
				if(rs > 0)
				{
					System.out.println(rs+" rows inserted in database");
					System.out.println("Product Added Successfully!!!");
					System.out.println();
					return true;
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			System.out.println("Connection Established but Error Inserting Data!!!");
			return false;
		}
		else
		{
			System.out.println("Error Connecting the Database!!!");
			return false;
		}
	}
	
	public static boolean deleteProduct(int id)
	{
		Connection conn = DBUtil.getConnection();
		
		if(conn!=null)
		{
			try
			{
				PreparedStatement stat = conn.prepareStatement("delete from product where id=?");
				stat.setInt(1, id);
				int rs = stat.executeUpdate();
				
				if(rs > 0)
				{
					System.out.println(rs+" row deleted from database");
					System.out.println("Product Deleted Successfully!!");
					System.out.println();
					return true;
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			System.out.println("Connection Established but failed to Delete data!!!");
			return false;
		}
		else
		{
			System.out.println("Cannot Establish connection to database");
			return false;
		}
	}
	
	public static boolean updateProduct(int id)
	{
		Connection conn = DBUtil.getConnection();
		
		if(conn!=null)
		{
			try
			{
				@SuppressWarnings("resource")
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter New Product Name: ");
				String name = sc.nextLine();
				System.out.println("Enter New Product Price: ");
				int price = sc.nextInt();
				
				PreparedStatement stat = conn.prepareStatement("update product set id=?, name=?, price=? where id=?");
				stat.setInt(1, id);
				stat.setString(2, name);
				stat.setInt(3, price);
				stat.setInt(4, id);
				
				int rs = stat.executeUpdate();
				
				if(rs > 0)
				{
					System.out.println(rs+" rows updated in database");
					System.out.println("Update was Successfull!!");
					System.out.println();
					return true;
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			System.out.println("Connection Established but failed to update data");
			return false;
		}
		else
		{
			System.out.println("Error Connecting to Database!!");
			return false;
		}
	}
	
	public static List<Product> getProducts()
	{
		Connection conn = DBUtil.getConnection();
		List<Product> products = new ArrayList<Product>();
		if(conn!=null)
		{
			try
			{
				String query = "select * from product";
				Statement stat = conn.createStatement();
				
				ResultSet rs = stat.executeQuery(query);
				
				while(rs.next())
				{
					Product prod = new Product();
					prod.setId(rs.getInt("id"));
					prod.setName(rs.getString("name"));
					prod.setPrice(rs.getInt("price"));
					products.add(prod);
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		return products;
	}
	
	public static void searchProduct(int id)
	{
		Connection conn = DBUtil.getConnection();
		
		if(conn!=null)
		{
			try
			{
				PreparedStatement stat = conn.prepareStatement("select * from product where id=?");
				stat.setInt(1, id);
				
				ResultSet rs = stat.executeQuery();
				if(rs.next())
				{
					System.out.println("---Found Product---");
					System.out.println("Product id: "+rs.getInt(1));
					System.out.println("Product Name: "+rs.getString(2));
					System.out.println("Product Price: "+rs.getInt(3));
					System.out.println();
				}
				else
				{
					System.out.println("No Such Product Exists!!");
					System.out.println();
				}
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		else
		{
			System.out.println("Error Establishing Connection to Database!!");
		}
	}
}
